package abscon.instance.intension.arithmetic;

import abscon.instance.intension.types.Arity1Type;

public abstract class Arity1ArithmeticEvaluator extends ArithmeticEvaluator implements Arity1Type{
}
