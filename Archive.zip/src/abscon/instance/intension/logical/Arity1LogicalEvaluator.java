package abscon.instance.intension.logical;

import abscon.instance.intension.types.Arity1Type;


public abstract class Arity1LogicalEvaluator extends LogicalEvaluator implements Arity1Type {
}
