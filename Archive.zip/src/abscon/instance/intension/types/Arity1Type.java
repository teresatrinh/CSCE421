package abscon.instance.intension.types;

public interface Arity1Type {
}
