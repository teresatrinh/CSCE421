package abscon.instance.intension.relational;

import abscon.instance.intension.Evaluator;
import abscon.instance.intension.types.Arity2Type;
import abscon.instance.intension.types.BooleanType;

public abstract class RelationalEvaluator extends Evaluator implements BooleanType, Arity2Type {
}
