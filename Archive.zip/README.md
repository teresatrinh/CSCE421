# Homework 4
## Teresa Trinh

This file contains java code to read in an .xml file of a csp and conduct searching algorithms, namely BT and CBJ. 
Use the runProgram.sh file with -f flag for the file name, -s flag for the search algorithm, and -u flag for ordering heuristic.