# Homework 2
## Teresa Trinh

This file contains java code to read in an .xml file of a csp and conduct arc consistency (AC-1 and AC-3). 
Use the runProgram.sh file with -f flag for the file name, -a flag for the arc consistency algorithm.